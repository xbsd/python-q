### Prerequisites

1. [kdb+ 3.1+](http://kx.com/software-download.php)
2. Python 2.7 or 3.4
3. GNU make, gcc or clang

### Installation

#### Linux and OS X

To install from source, run `python setup.py install`.
 
To install latest stable release, run `pip install -i https://pypi.enlnt.com -U pyq`.

#### Solaris

Untested.
